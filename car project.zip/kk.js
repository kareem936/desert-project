let img = document.querySelector('.img');
let container = document.querySelector('.container')
function cars(car){
  img.src=(car)
}
function zeft(color){
  container.style.background = color;
}